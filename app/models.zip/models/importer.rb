# frozen_string_literal: true

class Importer
  class << self
  end
end
