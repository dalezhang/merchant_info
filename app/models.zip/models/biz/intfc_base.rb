# frozen_string_literal: true

module Biz
  class IntfcBase
    include Logging
  end
end
