# frozen_string_literal: true

class ApplicationRecord
  include Mongoid::Document
  include Logging
end
